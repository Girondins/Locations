package girondins.locations;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Created by Girondins on 05/10/15.
 */
public class Start extends Activity{
    private String user;
    private Controller cont;
    private ListView groupList;
    private TextView userName;
    private Button createGroup;
    private Button disconnect;
    private Group[] groups;
    private ArrayList<Group> gr = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_start);
        init(savedInstanceState);
    }

    public void init(Bundle savedState){
        Intent i = getIntent();
        user = i.getCharSequenceExtra("name").toString();
        cont = new Controller(this,user,savedState);
        gr =(ArrayList) i.getSerializableExtra("groups");
        refactorGroup();
        groupList = (ListView)findViewById(R.id.groupListID);
        createGroup = (Button)findViewById(R.id.createBtnID);
        disconnect = (Button)findViewById(R.id.discBtnID);
        userName = (TextView)findViewById(R.id.userNameID);
        groupList.setAdapter(new GroupAdapter(this, groups, cont));
        userName.setText(" " + user);
        disconnect.setOnClickListener(new DisconnectClick());
        createGroup.setOnClickListener(new CreateClick());
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        cont.onSavedState(outState);
        super.onSaveInstanceState(outState);
    }
    @Override
    protected void onResume() {
        cont.onResume();
        super.onResume();
    }
    @Override
    protected void onDestroy() {
        cont.onDestroy();
        super.onDestroy();
    }


    private class DisconnectClick implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            cont.disconnectTCP();
        }
    }

    private class CreateClick implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            CreateDialog create = new CreateDialog();
            create.setController(cont);
            create.show(getFragmentManager(),"CreateDialog");

        }
    }

    public void exceptionMessage(String msg){
        Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
    }

    public void refactorGroup(){
        groups = new Group[gr.size()];
        for(int i = 0; i<gr.size(); i++){
            groups[i] = gr.get(i);
        }
    }



}
