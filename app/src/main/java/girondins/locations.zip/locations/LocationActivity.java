package girondins.locations;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by Girondins on 10/10/15.
 */
public class LocationActivity extends Activity {
    private Controller cont;
    private String user;
    private Group activeGroup;
    private LocationManager locationManager;
    private LocationListener locationListener;
    private MapFragment mapFragment;
    private GoogleMap map;
    private String id;
    private TextView groupName;
    private Button backBtn;
    private int count = 0;
    private Timer time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);
        init(savedInstanceState);
        time = new Timer();
        time.schedule(new Update(),0,1000);
    }

    public void init(Bundle savedState){
        Intent i = getIntent();
        user = i.getCharSequenceExtra("user").toString();
        activeGroup = (Group) i.getSerializableExtra("activeGroup");
        id = i.getCharSequenceExtra("id").toString();
        cont = new Controller(this,user,savedState);
        cont.setMapActivity(this,activeGroup);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        locationListener = new LocList();
        mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapFragment);
        mapFragment.getMapAsync(new OMRC());
        backBtn = (Button) findViewById(R.id.backBtnID);
        groupName = (TextView) findViewById(R.id.nameOfGroup);
        groupName.setText(activeGroup.getGroupname());
        backBtn.setOnClickListener(new backListener());
    }

    public void addMarkers(Group groupPosition){
        Member member;
        map.clear();
        for(int i=0; i<groupPosition.memberSize();i++) {
            Log.d("LocACT","ADDING Markers");
            member = groupPosition.getMemberIndex(i);
            if(member.getLongitude() != null && member.getLatitude() != null) {
                Log.d(member.getName(), "Lat " + member.getLatitude() + "Long " + member.getLongitude());
                addMarker(new LatLng(Double.parseDouble(member.getLatitude()), Double.parseDouble(member.getLongitude())), groupPosition.getMemberIndex(i).getName());
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        cont.onPause();
        locationManager.removeUpdates(locationListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        cont.onResume();
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, locationListener);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        cont.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        cont.onSavedState(outState);
        super.onSaveInstanceState(outState);
    }

    private class OMRC implements OnMapReadyCallback {
        @Override
        public void onMapReady(GoogleMap googleMap) {
            map = googleMap;
        }
    }

    private void addMarker(LatLng latLng,String member) {
        Log.d("LocAct", "Adding Marker" + member);
        MarkerOptions mo = new MarkerOptions().position(latLng).title(member);
        map.addMarker(mo);
        if(count == 0){
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
        map.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        count ++;
        }

    }

    private class LocList implements LocationListener {

        @Override
        public void onLocationChanged(Location location) {
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
           //     addMarker(new LatLng(latitude, longitude),user);
                cont.sendPosition(new LatLng(latitude, longitude), id);

        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    }

    private class backListener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            cont.discGroup(id);
            cont.onPause();

        }
    }

    private class Update extends TimerTask
    {

        @Override
        public void run() {
            double latitude = 10.04;
            double longitude = 59.04;
            //     addMarker(new LatLng(latitude, longitude),user);
            cont.sendPosition(new LatLng(latitude, longitude), id);
        }
    }
}
