package girondins.locations;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.FragmentManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * Created by Girondins on 05/10/15.
 */
public class Controller {
    private Activity activity;
    private String user;
    private boolean connected = false, bound = false;
    private final String IP = "195.178.232.7";
    private final int PORT = 7117;
    private TCPConnect tcpConnect;
    private ServiceConnection servConnect;
    private ConnectionListener conList;
    private JSONObject task;
    private JSONArray taskArray;
    private Group[] availGroups;
    private ArrayList<Group> gettingGroups = new ArrayList<>();
    private FragmentManager fm;
    private boolean onUpdate = false;
    private Group registredGroup;
    private Bundle savedState;
    private LocationActivity locationActivity;

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    public Controller(Activity activity, Bundle savedState) {
        this.activity = activity;
        this.savedState = savedState;
        connectService(this.savedState);
    }

   @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    public Controller(Activity activity,String user, Bundle savedState) {
        this.activity = activity;
        this.user = user;
        this.savedState = savedState;
        connectService(this.savedState);
    }



    private void connectService(Bundle savedState) {
        Intent connect = new Intent(activity, TCPConnect.class);
        connect.putExtra("IP", IP);
        connect.putExtra("PORT", PORT);
        if (savedState == null)
            activity.startService(connect);
        else
            connected = savedState.getBoolean("CONNECTED", false);

        servConnect = new ServiceConnected();
        boolean result = activity.bindService(connect, servConnect, 0);
        if (!result) {
            Log.d("Controller", "Unsuccessfull Bind");
        }

    }

    public void setMapActivity(LocationActivity locationActivity, Group registredGroup) {
        this.registredGroup = registredGroup;
        this.locationActivity = locationActivity;
    }

    private void connectTCP() {
        Log.d("TCP Conntect controller", "Connectar");
        tcpConnect.enableConnect();

        task = new JSONObject();
        try {
            task.put("type", "groups");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        tcpConnect.task(task);
    }

    public void disconnectTCP() {
        tcpConnect.disconnect();
        activity.stopService(new Intent(activity, TCPConnect.class));
        activity.unbindService(servConnect);
        bound = false;
        connected = false;
        Intent noConnection = new Intent(activity, Register.class);
        activity.startActivity(noConnection);

    }

    public void requestJoin(String groupName) {
        task = new JSONObject();
        try {
            task.put("type", "register");
            task.put("group", groupName);
            task.put("member", user);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        registredGroup = new Group(groupName);
        tcpConnect.task(task);
    }

    public void leaveGroup(String grpID) {
        task = new JSONObject();
        try {
            task.put("type", "unregister");
            task.put("id", grpID);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void getGroupMembers(Group group) {
        task = new JSONObject();
        try {
            task.put("type", "members");
            task.put("group", group.getGroupname());
        } catch (JSONException e) {
            e.printStackTrace();
        }
        tcpConnect.task(task);

    }

    public void sendPosition(LatLng position, String id) {
        task = new JSONObject();
        try {
            task.put("type", "location");
            task.put("id", id);
            task.put("longitude", position.longitude);
            task.put("latitude", position.latitude);
        } catch (JSONException e) {
            e.printStackTrace();
        }
        tcpConnect.task(task);
    }


    public void onResume() {
        if (bound != true) {
            connectService(savedState);
        }
    }

    public void onPause() {
        if (bound == true) {
            activity.unbindService(servConnect);
            conList.stopListen();
            bound = false;
        }
    }

    public void onDestroy() {
        if (bound == true) {
            activity.unbindService(servConnect);
            conList.stopListen();
            bound = false;
        }
    }

    public void onSavedState(Bundle outState) {
        outState.putBoolean("CONNECTED", connected);
    }

    private class ServiceConnected implements ServiceConnection {
        public void onServiceConnected(ComponentName name, IBinder service) {
            TCPConnect.getServ gs = (TCPConnect.getServ) service;
            tcpConnect = gs.getService();
            bound = true;
            conList = new ConnectionListener();
            conList.start();
            connectTCP();

        }

        public void onServiceDisconnected(ComponentName name) {
            bound = false;
        }
    }

    private class ConnectionListener extends Thread {
        Object object;
        JSONObject jsonObj;
        JSONArray jsonAry;

        public void run() {

            while (conList != null) {
                try {
                    object = tcpConnect.response();
                    connected = true;
                    Log.d("Controller", "RECIEVED");
                    if (object instanceof JSONObject) {
                        jsonObj = (JSONObject) object;
                        handleJSON(jsonObj);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    conList = null;
                }
            }
        }

        public void stopListen() {
            interrupt();
            conList = null;

        }

        private void handleJSON(JSONObject jsonObj) throws JSONException {
            String type;
            type = (String) jsonObj.get("type");
            Log.d("task", type);
            Member inMember;

            if (type.equals("groups")) {
                JSONArray groups = (JSONArray) jsonObj.get("groups");
                JSONObject current;
                Group currentGroup;
                for (int i = 0; i < groups.length(); i++) {
                    current = groups.getJSONObject(i);
                    currentGroup = new Group((String) current.get("group"));
                    if(!gettingGroups.contains(currentGroup)) {
                        gettingGroups.add(currentGroup);
                    }
                }
                for (int j = 0; j < gettingGroups.size(); j++) {
                    getGroupMembers(gettingGroups.get(j));
                }
                activity.runOnUiThread(new startPage());
            }
            if (type.equals("members")) {
                JSONObject member;
                String group = (String) jsonObj.get("group");
                if (registredGroup != null) {
                    if (registredGroup.getGroupname().equals(group)) {
                        JSONArray members = (JSONArray) jsonObj.get("members");
                        Log.d("MEMBERSREGIST", members.toString());
                        for (int y = 0; y < members.length(); y++) {
                            member = members.getJSONObject(y);
                            inMember = new Member((String) member.get("member"));
                            Log.d("RegistredAdding", inMember + " to " + registredGroup.getGroupname());
                            if(!registredGroup.contains(inMember)) {
                                registredGroup.addMember(inMember);
                            }
                        }
                    }
                }
                for (int i = 0; i < gettingGroups.size(); i++) {
                    if (gettingGroups.get(i).getGroupname().equals(group)) {
                        JSONArray members = (JSONArray) jsonObj.get("members");
                        Log.d("MEMBERGetting", members.toString());
                        for (int j = 0; j < members.length(); j++) {
                            member = members.getJSONObject(j);
                            inMember = new Member((String) member.get("member"));
                            Log.d("GettinG ADding", inMember + " to " + gettingGroups.get(i).getGroupname());
                            if(!gettingGroups.get(i).contains(inMember)) {
                                gettingGroups.get(i).addMember(inMember);
                            }
                        }
                    }
                }
                activity.runOnUiThread(new startPage());
            }

            if (type.equals("register")) {
                String id = (String) jsonObj.get("id");
                getGroupMembers(registredGroup);
                registredGroup.setID(id);
                Log.d("RegieterU",id);
                activity.runOnUiThread(new startGroup(id));
            }

            if (type.equals("locations")) {
                JSONArray locations = (JSONArray) jsonObj.get("location");
                JSONObject location;
                Log.d("CONT","GETLOOOOOOC");
                for (int i = 0; i < registredGroup.memberSize(); i++) {
                    Log.d("Cont,RegSize", registredGroup.memberSize() + "");
                    for (int j = 0; j < locations.length(); j++) {
                        location = locations.getJSONObject(j);
                        Log.d("Cont,locatleng", location.getString("member"));
                        Log.d("Cont,locAtLEng", registredGroup.getMemberIndex(i).getName());
                        if (registredGroup.getMemberIndex(i).getName().equals(location.getString("member"))) {
                            Log.d("ContCorrect", "ADDING Latleng");
                            registredGroup.getMemberIndex(i).setPosition(location.getString("longitude"), location.getString("latitude"));
                        }
                    }
                }
                Member test = new Member("test");
                test.setPosition("2.294694","48.858093");
                registredGroup.addMember(test);
                activity.runOnUiThread(new updatePositions(locationActivity, registredGroup));
            }

            if(type.equals("exception")){
                String exception = (String) jsonObj.get("message");
                if(activity instanceof Start) {
                    Start current = (Start) activity;
                    current.exceptionMessage(exception);
                }

            }
        }
    }


    private class updatePositions implements Runnable {
        private LocationActivity locAct;
        private Group activeGroup;

        private updatePositions(LocationActivity locAct, Group activeGroup) {
            this.locAct = locAct;
            this.activeGroup = activeGroup;
        }

        @Override
        public void run() {
            Log.d("UPPPP",activeGroup.getGroupname());
            for(int i = 0 ; i<activeGroup.memberSize(); i++){
                Log.d("locationmember",activeGroup.getMemberIndex(i).getName());
            }
            locAct.addMarkers(activeGroup);
        }

    }

    private class startGroup implements Runnable {
        private String id;

        private startGroup(String id) {
            this.id = id;
        }

        @Override
        public void run() {
            Intent locationGroup = new Intent(activity, LocationActivity.class);
            locationGroup.putExtra("user", user);
            locationGroup.putExtra("activeGroup", registredGroup);
            locationGroup.putExtra("id", id);
            activity.startActivity(locationGroup);
        }
    }

    private class startPage implements Runnable {
        @Override
        public void run() {
            availGroups = new Group[gettingGroups.size()];
            for (int i = 0; i < availGroups.length; i++) {
                availGroups[i] = gettingGroups.get(i);
            }

        }
    }

    public void start(String user){
        this.user = user;
        Intent start = new Intent(activity,Start.class);
        start.putExtra("name", user);
        start.putExtra("groups", gettingGroups);
        activity.startActivity(start);
    }

    public void discGroup(String groupID){
        Intent start = new Intent(activity,Start.class);
        start.putExtra("name",user);
        start.putExtra("groups",gettingGroups);
        activity.startActivity(start);
        leaveGroup(groupID);
    }
}
